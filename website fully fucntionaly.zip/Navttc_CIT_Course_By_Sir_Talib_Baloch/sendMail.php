<form action="code.php" method="post">
    <input type="email" name="email" placeholder="Enter EMail"><br>
    <input type="text" name="subj" placeholder="Enter Subject"><br>
    <textarea name="msg" id="" cols="30" rows="10" placeholder="Enter Your Message"></textarea><br>
    <input type="submit" name="sendmail" value="Send">
</form>
<?php 



?>