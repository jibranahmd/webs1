<?php 
    $con = mysqli_connect("localhost","id21148285_root","Aptech@123","id21148285_navttc_db");
?>