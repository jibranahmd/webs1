<?php 
    $con = mysqli_connect("localhost","root","","navttc_db");
?>