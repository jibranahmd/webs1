-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2023 at 09:32 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `navttc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `navttc_users`
--

CREATE TABLE `navttc_users` (
  `student_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Pending',
  `std_city` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `Gender` varchar(100) NOT NULL,
  `Salry` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `navttc_users`
--

INSERT INTO `navttc_users` (`student_id`, `name`, `email`, `password`, `status`, `std_city`, `doj`, `Gender`, `Salry`) VALUES
(4, 'Ali Amjad Hyderabad', 'Users@gmail.com', 'users321', 'Pending', 'KHI', '2023-07-01', 'Male', 40000),
(5, 'Ali Ahmed', 'Ali@gmail.com', 'ali321', 'Completed', 'KHI', '2023-06-04', 'Male', 60000),
(6, 'Junaid Akhtar', 'Junaid@gmail.com', '321', 'Pending', 'HYD', '2023-07-11', 'Female', 80000),
(7, 'Ahmed Shah', 'Ahmed@gmail.com', 'Ahmed12', 'Pending', 'JAM', '2023-07-11', 'Female', 90000),
(8, 'Farooq Nawaz', 'Farooq@gail.com', 'fa123', 'Pending', 'KHI', '2023-06-11', 'Male', 50000),
(9, 'Abc', 'Abc@gmail.com', '123', 'Pending', 'KHI', '2023-07-10', 'Male', 60000),
(10, 'Xyz', 'Xyz@gmail.com', 'xyz123', 'Pending', 'HYD', '2023-07-10', 'Male', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `p_name` varchar(255) DEFAULT NULL,
  `p_price` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `p_name`, `p_price`, `date`) VALUES
(1, 7, 'Roll ', 50, '2023-07-12 07:11:30'),
(2, 9, 'Pizza', 1200, '2023-07-12 07:12:13');

-- --------------------------------------------------------

--
-- Table structure for table `shipment`
--

CREATE TABLE `shipment` (
  `s_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `s_status` varchar(255) NOT NULL DEFAULT 'Pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipment`
--

INSERT INTO `shipment` (`s_id`, `u_id`, `s_status`, `date`) VALUES
(1, 9, 'Pending', '2023-07-12 07:21:39'),
(2, 7, 'Completed', '2023-07-12 07:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `validationage`
--

CREATE TABLE `validationage` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL CHECK (`age` >= 18)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `validationage`
--

INSERT INTO `validationage` (`id`, `email`, `password`, `age`) VALUES
(1, 'Abc@gmail.com', '321', 20),
(2, 'Ali@gmail.com', '321', 24),
(4, 'Ahmed@gmail.com', '432', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `navttc_users`
--
ALTER TABLE `navttc_users`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `shipment`
--
ALTER TABLE `shipment`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `validationage`
--
ALTER TABLE `validationage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `navttc_users`
--
ALTER TABLE `navttc_users`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shipment`
--
ALTER TABLE `shipment`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `validationage`
--
ALTER TABLE `validationage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `navttc_users` (`student_id`);

--
-- Constraints for table `shipment`
--
ALTER TABLE `shipment`
  ADD CONSTRAINT `shipment_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `navttc_users` (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
